package com.aplikasi.bintangapps.Models;
/**
 * Nim : 10116341
 * Nama : Sella Bintang Sandy Prasastie
 * Kelas : AKB-8
 * UTS
 * Tanggal : 16 Mei 2019
 */
public class DailyActivityModel {
    private String title;
    private String description;

    public DailyActivityModel(String title, String description){
        this.title=title;
        this.description=description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
