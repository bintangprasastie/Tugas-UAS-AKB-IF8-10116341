package com.aplikasi.bintangapps.Models;
/**
 * Nim : 10116341
 * Nama : Sella Bintang Sandy Prasastie
 * Kelas : AKB-8
 * UTS
 * Tanggal : 16 Mei 2019
 */
public class FriendListModel {
    private String name,age;
    private int image;


    public FriendListModel(String name, String age, int image){
        this.name=name;
        this.age=age;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
