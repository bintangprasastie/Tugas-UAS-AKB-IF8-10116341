package com.aplikasi.bintangapps.Views;
/**
 * Nim : 10116341
 * Nama : Sella Bintang Sandy Prasastie
 * Kelas : AKB-8
 * UTS
 * Tanggal : 14 Mei 2019
 */
import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

import com.aplikasi.bintangapps.Presenter.OnBoardActivityAdapter;
import com.aplikasi.bintangapps.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class OnBoardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_board);
        ViewPager viewPager=(ViewPager) findViewById(R.id.pagerOnBoard);
        OnBoardActivityAdapter onBoardActivityAdapter=new OnBoardActivityAdapter(getSupportFragmentManager());
        viewPager.setAdapter(onBoardActivityAdapter);
//        TabLayout tabLayout = (TabLayout) viewFragment.findViewById(R.id.tablayout);
//        tabLayout.setupWithViewPager(viewPager);
    }


}
