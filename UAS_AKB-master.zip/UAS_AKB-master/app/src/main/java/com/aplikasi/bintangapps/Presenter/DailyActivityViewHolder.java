package com.aplikasi.bintangapps.Presenter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.aplikasi.bintangapps.R;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
/**
 * Nim : 10116341
 * Nama : Sella Bintang Sandy Prasastie
 * Kelas : AKB-8
 * UTS
 * Tanggal : 16 Mei 2019
 */
public class DailyActivityViewHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.txtDailyTitle)
    TextView txtDailyTitle;
    @BindView(R.id.txtDailyDescription)
    TextView txtDailyDescription;
    private ArrayList<String> dailyActivityModel=new ArrayList<>();
    public DailyActivityViewHolder(@NonNull View itemView) {
        super(itemView);
        ButterKnife.bind(this,itemView);
    }

    public void setItem(ArrayList<String> item){//penerima value dari adapter
        dailyActivityModel=item;
    }

}
